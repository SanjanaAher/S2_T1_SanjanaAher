﻿using System;

namespace Demo08_Constructors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Demo03.Demo.Run();
            //Console.WriteLine();

            //Demo04.Person p1 = new Demo04.Person("First person");
            //Demo04.Person p2 = new Demo04.Person("Second person");

            //Console.WriteLine("{0} {1}", p1.ID, p1.Name);
            //Console.WriteLine("{0} {1}", p2.ID, p2.Name);
            //Console.WriteLine();

            Demo05.Demo.Run();

        }
    }
}
