﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    [Table("Departments")]
    public class Department
    {
        [Display(Name = "Department Id")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int DepartmentId { get; set; }

        [Display(Name ="Department Name")]
        [Required(ErrorMessage = "{0} can't be empty.")]
        [StringLength(50, ErrorMessage = "{0} can't have more than {1} characters.")]
        [MinLength(3, ErrorMessage = "{0} must contain more than {1} characters.")]

        public string DepartmentName { get; set; }

        #region Navigation Properties to the Subject Model

        public ICollection<Subject> Subjects { get; set; }

        #endregion
    }
}
