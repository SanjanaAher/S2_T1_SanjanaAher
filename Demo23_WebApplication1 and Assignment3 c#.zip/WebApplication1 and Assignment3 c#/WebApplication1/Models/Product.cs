﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApplication1.Models
{
    [Table("Products")]
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductID { get; set; }


        [Display(Name = "Name of Product")]
        [Required(ErrorMessage = "{0} can't be empty.")]
        [StringLength(50, ErrorMessage = "{0} can't have more than {1} characters.")]
        [MinLength(3, ErrorMessage ="{0} must contain more than {1} characters.")]

        public string ProductName{ get; set; }

        [Required(ErrorMessage ="{0} cannot be Empty.")]
        [Range(minimum: 1, maximum:100, ErrorMessage ="{0} needs to be between {1} and {2}" )]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "{0} cannot be Empty.")]
        [Range(minimum: 1, maximum: 100, ErrorMessage = "{0} needs to be between {1} and {2}")]
        public int Price { get; set; }



    }
}
