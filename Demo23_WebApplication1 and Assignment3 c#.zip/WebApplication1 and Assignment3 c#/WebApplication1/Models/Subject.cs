﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace WebApplication1.Models
{


    [Table("Subjects")]
    public class Subject
    {
        [Display(Name = "Subject Id")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public short SubjectId { get; set; }

        [Display(Name = "Subject Name")]
        [Required(ErrorMessage = "{0} can't be empty.")]
        [StringLength(50, ErrorMessage = "{0} can't have more than {1} characters.")]
        [MinLength(3, ErrorMessage = "{0} must contain more than {1} characters.")]

        public string SubjectName { get; set; }

        #region Navigation Properties to the Department Model

        [Display(Name = "Department Name")]
        [Required]
        [ForeignKey(nameof(Subject.Department))]
        public int DepartmentId { get; set; }


        [Display(Name = "Department Name")]
        public Department Department { get; set; }

        #endregion
    }
}
