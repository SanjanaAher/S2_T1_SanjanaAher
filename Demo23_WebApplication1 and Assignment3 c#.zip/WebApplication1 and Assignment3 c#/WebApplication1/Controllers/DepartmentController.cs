﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Data;
namespace WebApplication1.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ApplicationDbContext _context;
        public DepartmentController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            //Using Linq
            //var query = from dept in _context.Departments
            // select dept;

            // return View(query);

            //using Lambda
            var depts = _context.Departments.ToList();
            return View(depts);
        }
    }
}
