﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo26_Task
{
    class Demo02
    {
        public static void Run()
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Running Task #1 on Thread {0}.",
                    Thread.CurrentThread.ManagedThreadId);
            });
            Task t2 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Running Task #2 on Thread {0}.",
                    Thread.CurrentThread.ManagedThreadId);
            });
            Task t3 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Running Task  #3on Thread {0}.",
                    Thread.CurrentThread.ManagedThreadId);
            });

            Task.WaitAll(t1, t2, t3);
            Console.WriteLine("--- Finished the 1st three task");
            Console.WriteLine();

            //Fluid Code/Chain Calls
            //Execute Task one after other
            Task.Factory
                .StartNew(() =>
                {
                    Console.WriteLine("This is Step1 on Thread : {0}",
                        Thread.CurrentThread.ManagedThreadId);
                })
                .ContinueWith((t) =>
               {
                   Console.WriteLine("This is Step2 on Thread : {0}",
                        Thread.CurrentThread.ManagedThreadId);
               })
                .ContinueWith((t) =>
                {
                    Console.WriteLine("This is Step3 on Thread : {0}",
                        Thread.CurrentThread.ManagedThreadId);
                });


        }
    }
}
