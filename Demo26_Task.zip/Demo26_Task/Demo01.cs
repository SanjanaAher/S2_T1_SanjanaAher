﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo26_Task
{
    class Demo01
    {
        public static void DoSomething()
        {
            Console.WriteLine("Hello World from Task Lib");
        }

        public static void Run()
        {
            //---Called using Thread
            Thread t1 = new Thread(new ThreadStart(Demo01.DoSomething));
            t1.Start();

            Console.WriteLine();
            //---Called using ThreadStart Delegate
            Console.WriteLine("Calling Through ThreadStart Delegate");
            ThreadStart t2 = new ThreadStart(() =>
             {
                 Demo01.DoSomething();

             });
            t2.Invoke();
            Console.WriteLine();

            //Called using Task Parallel Lib
            Task.Factory.StartNew(() => { 
            
                Console.WriteLine();
                Console.WriteLine("Calling Through TPL");
               // Demo01.DoSomething();

            });
            Task.WaitAll();
        }
    }
}
