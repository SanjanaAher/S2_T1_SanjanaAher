﻿using System;

namespace Demo26_Task
{
    class Program
    {
        static void Main(string[] args)
        {
            Demo01.Run();

            Console.WriteLine();

            Demo02.Run();
        }
    }
}
