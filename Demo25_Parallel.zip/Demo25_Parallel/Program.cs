﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Demo25_Parallel
{
    class Program
    {
        private static void displaynumber(int a)
        {
            System.Threading.Thread.Sleep(100);
            Console.WriteLine("i = {0} on Thread {1}",
                a, Thread.CurrentThread.ManagedThreadId);
        }
        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Console.WriteLine("--- For Loop");
            stopwatch.Start();
            for(int i =0; i< arr.Length; i++)
            {
                displaynumber(arr[i]);

            }
            stopwatch.Stop();
            Console.WriteLine("Elapsed Time: {0} millisec [ {1} ticks ]",
                stopwatch.ElapsedMilliseconds,stopwatch.ElapsedTicks);
            Console.WriteLine();

            Console.WriteLine("--- Parallel For Loop");
            stopwatch.Start();
            Parallel.For(0, arr.Length, i =>
              {
                  displaynumber(arr[i]);
              });
            
           stopwatch.Stop();
            Console.WriteLine("Elapsed Time: {0} millisec [ {1} ticks ]",
                stopwatch.ElapsedMilliseconds, stopwatch.ElapsedTicks);
            Console.WriteLine();

            Console.WriteLine("--- Foreach Loop");
            stopwatch.Restart();
            foreach (int i in arr)
            {
                displaynumber(i);
            }
            stopwatch.Stop();
            Console.WriteLine("Elapsed Time: {0} millisec [ {1} ticks ]",
               stopwatch.ElapsedMilliseconds, stopwatch.ElapsedTicks);
            Console.WriteLine();

            Console.WriteLine("---Parallel Foreach Loop");
            stopwatch.Restart();
            Parallel.ForEach(arr, i =>
             {
                 displaynumber(i);
             });
            
            stopwatch.Stop();
            Console.WriteLine("Elapsed Time: {0} millisec [ {1} ticks ]",
               stopwatch.ElapsedMilliseconds, stopwatch.ElapsedTicks);
            Console.WriteLine();
        }
    }
}
