﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo16_Delegate
{
    class Car
    {
        public void DriveCar()
        {
            Console.WriteLine("Car is being driven");
        }
    }
}
