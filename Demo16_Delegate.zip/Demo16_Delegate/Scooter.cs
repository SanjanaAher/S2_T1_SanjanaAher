﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo16_Delegate
{
    class Scooter
    {
        public void DriveScooter()
        {
            Console.WriteLine("Scooter is being driven now!");
        }
    }
}
