﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Demo27_Task_AsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            bool result;
            Console.WriteLine("MAIN is running on Thread: {0}",
                 Thread.CurrentThread.ManagedThreadId);
            Console.WriteLine();

            Console.WriteLine("--Running Synchronously");
            result=Program.ProcessJob(10);
            Console.WriteLine("Result: {0}", result);
            Console.WriteLine();

            Console.WriteLine("---Running Asynchronously");
            Task<bool> retVal = ProcessJobAsync(100);
            Console.WriteLine("Waiting for the Result");
            retVal.Wait();
            result = retVal.Result;
            Console.WriteLine("Result: {0}", result);
            Console.WriteLine();

        }

        private static async Task<bool> ProcessJobAsync(int i)
        {
            return await Task.Run( () => ProcessJob(i));


        }
        private static bool ProcessJob(int i)
        {
            Thread.Sleep(5000);

            Console.WriteLine("ProcessJob was called with i ={0} on thread: {1}",
                i, Thread.CurrentThread.ManagedThreadId);

            return true;
        }
    }
}
