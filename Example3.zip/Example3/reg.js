 function form_validation() {
                var userid = 
                document.forms["registration"]["userid"];
                var password= 
                    document.forms["registration"]["password"];
                var name = 
                    document.forms["registration"]["name"];
                var address = 
                    document.forms["registration"]["address"];
                var country =
                    document.forms["registration"]["country"];
                var zipcode = 
                    document.forms["registration"]["zipcode"];
                var email = 
                    document.forms["registration"]["email"];
                var sex = 
                    document.forms["registration"]["sex"];
               
                console.log(name.value);
             
                if (name.value == "") {
                    window.alert("Please enter your name.");
                    name.focus();
                    
                    // return false;
                }

                if (!/^[a-zA-Z]*$/g.test(name.value)) {
                    alert("Please Enter A valid Name");
                    name.focus();
                    // return false;
                }
  
               if (address.value == "") {
                    window.alert("Please enter your address.");
                    address.focus();
                    return false;
                }
  
                if (email.value == "") {
                    window.alert(
                      "Please enter a valid e-mail address.");
                    email.focus();
                    return false;
                }
  
               
  
                if (password.value == "") {
                    window.alert("Please enter your password");
                    password.focus();
                    return false;
                }

                if (userid.value == "") {
                    window.alert("Please enter your address.");
                    address.focus();
                    return false;
                }
  
              
  
                return true;
            }
        