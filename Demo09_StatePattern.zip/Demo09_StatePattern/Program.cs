﻿using System;

namespace Demo09_StatePattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount("Ganpat University");

            account.Deposit(80000.00);
            account.Deposit(5000.00);
            account.Deposit(95000.00);
            account.Withdraw(50000.00);
            account.Withdraw(8000.00);
        }
    }
}
