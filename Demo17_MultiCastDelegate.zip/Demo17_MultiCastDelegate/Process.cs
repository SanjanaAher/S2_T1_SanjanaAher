﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo17_MultiCastDelegate
{
    class Process
    {
        public void Step01()
        {
            Console.WriteLine("--- step 01 completed");
        }


        public void Step02()
        {
            Console.WriteLine("--- step 02 completed");
        }

        public void Step03()
        {
            Console.WriteLine("--- step 03 completed");
        }

        public void Step04()
        {
            Console.WriteLine("--- step 04 completed");
        }

        public void Step05()
        {
            Console.WriteLine("--- step 05 completed");
        }

        public void Step06()
        {
            Console.WriteLine("--- step 06 completed");
        }

        public void Step07()
        {
            Console.WriteLine("--- step 07 completed");
        }

        public void Step08()
        {
            Console.WriteLine("--- step 08 completed");
        }

        public void Step09()
        {
            Console.WriteLine("--- step 09 completed");
        }

        public void Step10()
        {
            Console.WriteLine("--- step 10 completed");
        }

    }
}
