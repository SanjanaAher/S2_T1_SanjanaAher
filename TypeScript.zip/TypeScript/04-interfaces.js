var user;
//user = { anything: 'some data' };
user = { username: 'sanjana', password: 'Swaar' };
user = { username: 'sanjana', password: 'Swaar', confirmPassword: 'Swaar' };
console.log('user information');
console.log('user.username');
console.log('user.password');
var car = {
    accelerate: function (speed) {
        console.log('accelerate now to' + speed);
    }
};
car.accelerate(500);
