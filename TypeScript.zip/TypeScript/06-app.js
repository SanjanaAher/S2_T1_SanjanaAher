"use strict";
exports.__esModule = true;
var _06_addModule_1 = require("./06-addModule");
var addObject = new _06_addModule_1.Addition(10, 20);
addObject.sum();
