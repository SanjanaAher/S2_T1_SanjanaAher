//Strongly typed variables

let myString: string;
myString= "This is a string value";

//myString=4; 			//generate a compiler error

let myString2: string="This is another string value";

//Typescript can infer the type on assignment

let myString3="This is a string value";
myString3=50;  			 //type:string is infered

let myVariable; 		//let myVariable :any;
myVariable="some string here";
myVariable=30;
myVariable=false;

let vString: string;
letvNumber: number;
let vBoolean: boolean;
let vObject: any;

let vArray: Array<string>;