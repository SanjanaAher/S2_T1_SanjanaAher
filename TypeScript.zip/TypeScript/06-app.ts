
import { Addition } from './06-addModule'
let addObject = new Addition(10, 20);
addObject.sum();