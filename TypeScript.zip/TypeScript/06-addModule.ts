export class Addition {
   

    constructor(private x?: number, private y?: number)
    {
    
    }
    sum() {
        console.log('Sum:' + (this.x + this. y));

    }
}