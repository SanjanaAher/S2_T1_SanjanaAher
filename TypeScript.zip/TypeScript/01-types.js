//Strongly typed variables
var myString;
myString = "This is a string value";
//myString=4; //generate a compiler error
var myString2 = "This is another string value";
//Typescript can infer the type on assignment
var myString3 = "This is a string value";
myString3 = 50;
