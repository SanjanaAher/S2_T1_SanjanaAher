var numberArray;
numberArray = [1, 2, 3, 4, 5];
numberArray = ["hello", 5, 'world']; //compile error
