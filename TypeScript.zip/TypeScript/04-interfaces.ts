interface IUSer {
	username: string;
	password: string;
	confirmPassword?: string; //optional field
}
let user: IUSer;
//user = { anything: 'some data' };

user = { username: 'sanjana', password: 'Swaar' };
user = { username: 'sanjana', password: 'Swaar', confirmPassword: 'Swaar' };

console.log('user information');
console.log('user.username');
console.log('user.password');

//Another example
interface ICar {
	accelerate(speed: number): void;
}

let car: ICar={
	accelerate: function(speed: number): void{
		console.log('accelerate now to' + speed);
	}
}
car.accelerate(500);