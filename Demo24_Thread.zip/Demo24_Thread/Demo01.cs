﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo24_Thread
{
    class Demo01
    {
        private static void DoThis()
        {
            Console.WriteLine("--- DoThis() called on Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);
        }

        public static void RunThis()
        {
            Console.WriteLine("Running in Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);

            DoThis();

            Console.WriteLine("Doing Something else in Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);
        }
    }
}
