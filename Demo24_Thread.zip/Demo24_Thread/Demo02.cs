﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo24_Thread
{
    class Demo02
    {
        private static void DoThis()
        {
            Console.WriteLine("--- DoThis() called on Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);
        }

        public static void RunThis()
        {
            Console.WriteLine("Running in Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);

            //Calling it Synchronously
            //Demo02.DoThis();

            //Calling it Asynchronously
            Thread t = new Thread(new ThreadStart(Demo02.DoThis));
            t.Start();

            Console.WriteLine("Doing Something else in Thread: {0}",
                Thread.CurrentThread.ManagedThreadId);

            Thread t2 = new Thread(() =>
              {
                  Thread.Sleep(1000);
                  Console.WriteLine("--anonymous method called on Thread: {0}",
                    Thread.CurrentThread.ManagedThreadId);

              });
            t2.Start();
        }
    }
}
