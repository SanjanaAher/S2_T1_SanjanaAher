﻿using System;

namespace Demo24_Thread
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Synchronous Demo");
            Demo01.RunThis();
            Console.WriteLine();

            Console.WriteLine("---Asynchronous Demo");
            Demo02.RunThis();
        }
    }
}
