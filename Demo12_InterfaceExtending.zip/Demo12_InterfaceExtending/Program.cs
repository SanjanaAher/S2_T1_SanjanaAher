﻿using System;

namespace Demo12_Interface_Extending
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
