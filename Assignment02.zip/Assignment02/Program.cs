﻿using System;

namespace Assignment02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo01.Run.RunThis();
        }
    }
}
